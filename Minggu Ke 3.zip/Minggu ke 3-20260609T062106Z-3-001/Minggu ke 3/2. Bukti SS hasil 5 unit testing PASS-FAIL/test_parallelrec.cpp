/*
 * ============================================================
 *  ParallelRec - UNIT TEST (Minggu 3)
 *  Kelompok 10: Muhammad Nazril, Yeand Saltama,
 *               Ian Grizeld Turang, Mikael Andiwijayaliano
 *  Mata Kuliah: Komputasi Paralel dan Terdistribusi
 * ============================================================
 *
 * Cara compile:
 *   g++ -fopenmp -o test_parallelrec test_parallelrec.cpp
 *
 * Cara jalankan:
 *   ./test_parallelrec
 * ============================================================
 */

#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <algorithm>
#include <chrono>
#include <cassert>
#include <omp.h>

using namespace std;
using namespace chrono;

// ==================== SALIN STRUKTUR DATA & FUNGSI ====================

struct Pengguna {
    int id;
    string nama;
    vector<string> hobi;
};

struct Jurusan {
    string nama;
    map<string, int> bobot_hobi;
};

struct Rekomendasi {
    string jurusan;
    int skor;
};

vector<Jurusan> buatDatabaseJurusan() {
    return {
        { "Teknik Informatika", {
            {"coding", 30}, {"pemrograman", 30}, {"logika", 25},
            {"matematika", 20}, {"games", 15}, {"teknologi", 20},
            {"komputer", 25}, {"algoritma", 25}
        }},
        { "Desain Komunikasi Visual", {
            {"menggambar", 30}, {"desain", 30}, {"seni", 25},
            {"fotografi", 20}, {"kreatif", 25}, {"warna", 20},
            {"ilustrasi", 25}, {"animasi", 20}
        }},
        { "Teknik Elektro", {
            {"elektronika", 30}, {"robotika", 30}, {"fisika", 25},
            {"matematika", 20}, {"teknologi", 20}, {"komputer", 15},
            {"mesin", 15}, {"listrik", 25}
        }},
        { "Psikologi", {
            {"sosial", 25}, {"menulis", 20}, {"membaca", 20},
            {"membantu", 30}, {"komunikasi", 25}, {"musik", 10},
            {"seni", 10}, {"konseling", 30}
        }},
        { "Manajemen Bisnis", {
            {"bisnis", 30}, {"komunikasi", 25}, {"sosial", 20},
            {"kepemimpinan", 30}, {"ekonomi", 25}, {"organisasi", 20},
            {"presentasi", 20}, {"negosiasi", 25}
        }},
        { "Kedokteran", {
            {"biologi", 30}, {"kimia", 25}, {"membantu", 25},
            {"membaca", 20}, {"penelitian", 25}, {"sains", 25},
            {"kesehatan", 30}, {"anatomi", 30}
        }},
        { "Ilmu Komunikasi", {
            {"menulis", 30}, {"komunikasi", 30}, {"sosial", 25},
            {"fotografi", 20}, {"presentasi", 25}, {"jurnalisme", 30},
            {"media", 25}, {"berbicara", 25}
        }},
        { "Sistem Informasi", {
            {"komputer", 25}, {"bisnis", 20}, {"coding", 20},
            {"logika", 20}, {"teknologi", 25}, {"data", 30},
            {"analisis", 25}, {"database", 30}
        }},
    };
}

vector<Rekomendasi> hitungRekomendasi(
    const Pengguna& pengguna,
    const vector<Jurusan>& jurusan_list
) {
    vector<Rekomendasi> hasil;
    for (const auto& j : jurusan_list) {
        int skor = 0;
        for (const auto& hobi : pengguna.hobi) {
            auto it = j.bobot_hobi.find(hobi);
            if (it != j.bobot_hobi.end()) skor += it->second;
        }
        hasil.push_back({j.nama, skor});
    }
    sort(hasil.begin(), hasil.end(), [](const Rekomendasi& a, const Rekomendasi& b) {
        return a.skor > b.skor;
    });
    if (hasil.size() > 3) hasil.resize(3);
    return hasil;
}

// ==================== FRAMEWORK TEST SEDERHANA ====================

int total_test = 0;
int test_pass  = 0;
int test_fail  = 0;

void cekTest(const string& nama_test, bool kondisi) {
    total_test++;
    if (kondisi) {
        cout << "  [PASS] " << nama_test << endl;
        test_pass++;
    } else {
        cout << "  [FAIL] " << nama_test << " <-- GAGAL!" << endl;
        test_fail++;
    }
}

// ==================== UNIT TEST ====================

// --------------------------------------------------
// TEST 1: Output tidak kosong
// Memastikan sistem menghasilkan rekomendasi
// --------------------------------------------------
void test1_output_tidak_kosong() {
    cout << "\n[TEST 1] Output tidak kosong" << endl;

    auto jurusan_list = buatDatabaseJurusan();
    Pengguna p = {1, "Test User", {"coding", "logika"}};

    auto hasil = hitungRekomendasi(p, jurusan_list);

    cekTest("Hasil tidak kosong", !hasil.empty());
    cekTest("Jumlah rekomendasi = 3", hasil.size() == 3);
    cekTest("Jurusan pertama tidak kosong", !hasil[0].jurusan.empty());
}

// --------------------------------------------------
// TEST 2: Rekomendasi benar sesuai hobi
// Pengguna coding+logika harus dapat Teknik Informatika
// --------------------------------------------------
void test2_rekomendasi_benar() {
    cout << "\n[TEST 2] Rekomendasi benar sesuai hobi" << endl;

    auto jurusan_list = buatDatabaseJurusan();
    Pengguna p = {2, "Coder", {"coding", "pemrograman", "algoritma", "logika"}};

    auto hasil = hitungRekomendasi(p, jurusan_list);

    cekTest("Rekomendasi #1 = Teknik Informatika", hasil[0].jurusan == "Teknik Informatika");
    cekTest("Skor #1 lebih besar dari skor #2",   hasil[0].skor >= hasil[1].skor);
    cekTest("Skor #2 lebih besar dari skor #3",   hasil[1].skor >= hasil[2].skor);
}

// --------------------------------------------------
// TEST 3: Hobi tidak dikenal tidak crash
// Skor = 0, program tetap jalan
// --------------------------------------------------
void test3_hobi_tidak_dikenal() {
    cout << "\n[TEST 3] Hobi tidak dikenal tidak crash" << endl;

    auto jurusan_list = buatDatabaseJurusan();
    Pengguna p = {3, "Unknown", {"hobiXYZ123", "hobiABC999"}};

    auto hasil = hitungRekomendasi(p, jurusan_list);

    cekTest("Program tidak crash",       !hasil.empty());
    cekTest("Jumlah hasil tetap 3",      hasil.size() == 3);
    cekTest("Semua skor = 0",            hasil[0].skor == 0 && hasil[1].skor == 0 && hasil[2].skor == 0);
}

// --------------------------------------------------
// TEST 4: Correctness — hasil paralel == sekuensial
// Ini test TERPENTING: output harus identik
// --------------------------------------------------
void test4_paralel_sama_dengan_sekuensial() {
    cout << "\n[TEST 4] Correctness: paralel == sekuensial" << endl;

    auto jurusan_list = buatDatabaseJurusan();
    vector<Pengguna> pengguna_list = {
        {1, "Nazril",  {"coding", "logika", "matematika", "algoritma"}},
        {2, "Yeand",   {"menggambar", "desain", "kreatif", "seni"}},
        {3, "Ian",     {"elektronika", "robotika", "fisika", "logika"}},
        {4, "Mikael",  {"bisnis", "komunikasi", "kepemimpinan", "sosial"}},
        {5, "User5",   {"biologi", "kimia", "sains", "membaca"}},
        {6, "User6",   {"menulis", "jurnalisme", "komunikasi", "fotografi"}},
        {7, "User7",   {"komputer", "data", "database", "analisis"}},
        {8, "User8",   {"musik", "seni", "kreatif", "desain"}},
    };
    int n = pengguna_list.size();

    // Versi PARALEL
    vector<vector<Rekomendasi>> hasil_paralel(n);
    #pragma omp parallel for schedule(static)
    for (int i = 0; i < n; i++) {
        hasil_paralel[i] = hitungRekomendasi(pengguna_list[i], jurusan_list);
    }

    // Versi SEKUENSIAL
    vector<vector<Rekomendasi>> hasil_seq(n);
    for (int i = 0; i < n; i++) {
        hasil_seq[i] = hitungRekomendasi(pengguna_list[i], jurusan_list);
    }

    // Bandingkan
    bool semua_sama = true;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < 3; j++) {
            if (hasil_paralel[i][j].jurusan != hasil_seq[i][j].jurusan ||
                hasil_paralel[i][j].skor    != hasil_seq[i][j].skor) {
                semua_sama = false;
            }
        }
    }

    cekTest("Jurusan #1 paralel == sekuensial (User 1)", hasil_paralel[0][0].jurusan == hasil_seq[0][0].jurusan);
    cekTest("Jurusan #1 paralel == sekuensial (User 2)", hasil_paralel[1][0].jurusan == hasil_seq[1][0].jurusan);
    cekTest("Semua 8 pengguna hasil identik",            semua_sama);
}

// --------------------------------------------------
// TEST 5: Performa paralel tidak lebih lambat 10x
// Minimal program paralel tidak jauh lebih lambat
// --------------------------------------------------
void test5_performa_paralel() {
    cout << "\n[TEST 5] Performa: paralel tidak jauh lebih lambat dari sekuensial" << endl;

    auto jurusan_list = buatDatabaseJurusan();

    // Buat 500 pengguna untuk uji performa
    vector<Pengguna> pengguna_list;
    vector<vector<string>> pool_hobi = {
        {"coding", "logika", "matematika"},
        {"menggambar", "desain", "kreatif"},
        {"biologi", "kimia", "sains"},
        {"bisnis", "komunikasi", "kepemimpinan"},
        {"menulis", "jurnalisme", "fotografi"},
    };
    for (int i = 0; i < 500; i++) {
        pengguna_list.push_back({i, "User" + to_string(i), pool_hobi[i % 5]});
    }
    int n = pengguna_list.size();

    // Paralel
    vector<vector<Rekomendasi>> hasil_paralel(n);
    auto t1 = high_resolution_clock::now();
    #pragma omp parallel for schedule(static)
    for (int i = 0; i < n; i++) {
        hasil_paralel[i] = hitungRekomendasi(pengguna_list[i], jurusan_list);
    }
    auto t2 = high_resolution_clock::now();
    double waktu_paralel = duration<double, milli>(t2 - t1).count();

    // Sekuensial
    vector<vector<Rekomendasi>> hasil_seq(n);
    auto t3 = high_resolution_clock::now();
    for (int i = 0; i < n; i++) {
        hasil_seq[i] = hitungRekomendasi(pengguna_list[i], jurusan_list);
    }
    auto t4 = high_resolution_clock::now();
    double waktu_seq = duration<double, milli>(t4 - t3).count();

    double speedup = (waktu_paralel > 0) ? waktu_seq / waktu_paralel : 1.0;

    cout << "    Waktu Sekuensial : " << waktu_seq    << " ms" << endl;
    cout << "    Waktu Paralel    : " << waktu_paralel << " ms" << endl;
    cout << "    Speedup          : " << speedup       << "x"  << endl;
    cout << "    Thread aktif     : " << omp_get_max_threads() << endl;

    cekTest("Waktu paralel < 10x waktu sekuensial", waktu_paralel < waktu_seq * 10);
    cekTest("Program paralel selesai (tidak hang)",  waktu_paralel < 5000.0);
    cekTest("500 hasil paralel tidak kosong",        !hasil_paralel[499].empty());
}

// ==================== MAIN ====================

int main() {
    cout << "================================================" << endl;
    cout << "  PARALLELREC - UNIT TEST RUNNER (Minggu 3)    " << endl;
    cout << "  Kelompok 10 | Komputasi Paralel & Terdistribusi" << endl;
    cout << "================================================" << endl;

    test1_output_tidak_kosong();
    test2_rekomendasi_benar();
    test3_hobi_tidak_dikenal();
    test4_paralel_sama_dengan_sekuensial();
    test5_performa_paralel();

    // ====== REKAP HASIL ======
    cout << "\n================================================" << endl;
    cout << "  REKAP HASIL UNIT TEST                        " << endl;
    cout << "================================================" << endl;
    cout << "  Total Test : " << total_test << endl;
    cout << "  PASS       : " << test_pass  << endl;
    cout << "  FAIL       : " << test_fail  << endl;
    cout << "------------------------------------------------" << endl;

    if (test_fail == 0) {
        cout << "  STATUS: SEMUA TEST PASS ✓" << endl;
    } else {
        cout << "  STATUS: ADA " << test_fail << " TEST GAGAL ✗" << endl;
    }
    cout << "================================================" << endl;

    return (test_fail == 0) ? 0 : 1;
}
